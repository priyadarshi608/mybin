name := """GSP-core-mq"""

version := "1.0-SNAPSHOT"

lazy val root = (project in file(".")).enablePlugins(PlayJava)

scalaVersion := "2.11.7"

libraryDependencies ++= Seq(
  javaJdbc,
  cache,
  javaWs,
  "org.apache.kafka" % "kafka-clients"  % "0.10.1.1",
  "com.googlecode.json-simple" % "json-simple" % "1.1"
)
